import {readFile, writeFile} from 'node:fs/promises'
import {getDate, monSecret} from "./divers.js";
import {NotFoundError} from "./errors.js";
import {createHash} from 'node:crypto'
import uuidv4 from "uuidv4";


/* Chemin de stockage des blocks */
const path = "./data/blockchain.json"

/**
 * Mes définitions
 * @typedef { id: string, nom: string, don: number, date: string,hash: string} Block
 * @property {string} id
 * @property {string} nom
 * @property {number} don
 * @property {string} date
 * @property {string} string
 *
 */

/**
 * Renvoie un tableau json de tous les blocks
 * @return {Promise<any>}
 */
export async function findBlocks() {
    try {
        return JSON.parse(await readFile(path, "utf-8"));
    } catch (error) {
        throw new Error("Erreur lors de la lecture du fichier blockchain.json : " + error.message);
    }
}

/**
 * Trouve un block à partir de son id
 * @param partialBlock
 * @return {Promise<Block[]>}
 */
export async function findBlock(partialBlock) {
    // A coder
}

/**
 * Trouve le dernier block de la chaine
 * @return {Promise<Block|null>}
 */
export async function findLastBlock() {
    try {

        const blocks = await findBlocks();
        if (blocks.length === 0) {
            return null;
        }
        return blocks[blocks.length - 1];

    } catch (error) {
        console.error(error.message);
        throw new Error('error');
    }
}

/**
 * Creation d'un block depuis le contenu json
 * @param contenu
 * @return {Promise<Block[]>}
 */
export async function createBlock(contenu) {
    try {
        let block = {
            id: uuidv4(),
            nom: contenu.nom,
            don: contenu.don,
            date: getDate(),
            hash: '',
        };

        const lastBlock = await findLastBlock();

        if (lastBlock !== null) {
            const hash = createHash('sha256').update(JSON.stringify(lastBlock)).digest('hex');
            block.hash = hash;
        }

        return block;
    } catch (error) {
        console.error(error.message);
        throw new Error('error');
    }
}
