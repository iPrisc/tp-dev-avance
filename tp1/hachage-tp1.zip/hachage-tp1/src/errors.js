/**
 * @description Permet d'obtenir une erreur spécifique pour les erreurs http 404
 */
export class NotFoundError extends Error {
}